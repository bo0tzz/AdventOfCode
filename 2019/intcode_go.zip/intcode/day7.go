package main

import (
	"strconv"
	"strings"
	"sync"
)

func d7p2(input string) {
	split := strings.Split(input, ",")

	mem := make([]int, len(split))
	for index, token := range split {
		i, err := strconv.Atoi(token)
		if err != nil {
			panic(err)
		}
		mem[index] = i
	}

	perm := []int{9, 8, 7, 6, 5}
	//p := prmt.New(prmt.IntSlice(perm))

	outputs := make([]int, 0)
	//for p.Next() {
	var wg sync.WaitGroup
	wg.Add(5)
	prevOut := make(chan int, 10) // Input for the first/next computer
	prevOut <- 0
	firstIn := prevOut
	computers := make([]computer, 0)
	for id, phase := range perm {
		var out chan int
		if id == 4 {
			out = firstIn
		} else {
			out = make(chan int, 10)
		}
		prevOut <- phase
		comp := newComputer(id, mem, prevOut, out, &wg)
		computers = append(computers, *comp)
		prevOut = out
	}
	for i := 0; i < len(computers); i++ {
		c := computers[i]
		go c.run()
	}
	println("Waiting for wg")
	wg.Wait()
	println("Done waiting")
	outputs = append(outputs, <-firstIn)
	//}
	largest := 0
	for _, o := range outputs {
		println(o)
		if o > largest {
			println(o, "is larger than", largest)
			largest = o
		}
	}
	println("max is", largest)

}
